"""
crypto_utils.py - Encryption/decryption helpers for the secure transaction demo.

Uses Fernet (AES-128-CBC with HMAC-SHA256 authentication) from the `cryptography`
package - a safe, well-studied symmetric encryption recipe suitable for an
academic demonstration. The demo key is generated once and stored locally.

NOTE: This is an academic demonstration. Do NOT use it to protect real payment
data or real credentials.
"""

import os
from cryptography.fernet import Fernet

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KEY_PATH = os.path.join(BASE_DIR, "database", "demo_secret.key")


def _load_key() -> bytes:
    """Load the demo encryption key, generating it on first run."""
    os.makedirs(os.path.dirname(KEY_PATH), exist_ok=True)
    if not os.path.exists(KEY_PATH):
        with open(KEY_PATH, "wb") as f:
            f.write(Fernet.generate_key())
    with open(KEY_PATH, "rb") as f:
        return f.read()


def get_fernet() -> Fernet:
    return Fernet(_load_key())


def encrypt_text(plain_text: str) -> str:
    """Encrypt a string and return URL-safe base64 ciphertext."""
    return get_fernet().encrypt(plain_text.encode("utf-8")).decode("ascii")


def decrypt_text(token: str) -> str:
    """Decrypt a Fernet token back to the original string."""
    return get_fernet().decrypt(token.encode("ascii")).decode("utf-8")


if __name__ == "__main__":
    demo = "order_id=1|amount=4999|method=UPI-DEMO"
    enc = encrypt_text(demo)
    dec = decrypt_text(enc)
    print("Original :", demo)
    print("Encrypted:", enc)
    print("Decrypted:", dec)
    assert dec == demo
    print("Round-trip OK")
