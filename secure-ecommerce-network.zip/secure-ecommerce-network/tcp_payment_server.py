"""
tcp_payment_server.py - In-app localhost TCP/IP "payment server" demo.

Runs inside the Flask app as a background thread on 127.0.0.1:5050.
The checkout flow encrypts the transaction payload, transmits it over a real
TCP socket to this server, which decrypts it and replies with an ACK.

Safe by design: it binds ONLY to 127.0.0.1 (localhost) and never accepts
connections from other machines.
"""

import socket
import threading
import time

HOST = "127.0.0.1"
PORT = 5050

_server_started = False
_server_lock = threading.Lock()


def _handle_client(conn, addr, decrypt_func):
    try:
        data = conn.recv(8192)
        if not data:
            return
        token = data.decode("ascii", errors="replace").strip()
        try:
            plain = decrypt_func(token)
            reply = f"ACK|DECRYPTED|{plain}"
        except Exception:
            reply = "NACK|DECRYPTION_FAILED"
        conn.sendall(reply.encode("utf-8"))
    finally:
        conn.close()


def start_payment_server(decrypt_func):
    """Start the demo payment server thread (idempotent)."""
    global _server_started
    with _server_lock:
        if _server_started:
            return
        try:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind((HOST, PORT))
            srv.listen(8)
        except OSError:
            # Port already in use (e.g. standalone network/server.py running)
            _server_started = True
            return

        def _loop():
            while True:
                try:
                    conn, addr = srv.accept()
                    threading.Thread(target=_handle_client,
                                     args=(conn, addr, decrypt_func),
                                     daemon=True).start()
                except OSError:
                    break

        threading.Thread(target=_loop, daemon=True).start()
        _server_started = True


def transmit_encrypted(token: str, timeout: float = 3.0):
    """
    Send the encrypted transaction token over TCP/IP to the demo payment
    server and return (reply, round_trip_ms, error).
    """
    start = time.perf_counter()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((HOST, PORT))
            s.sendall(token.encode("ascii"))
            reply = s.recv(8192).decode("utf-8", errors="replace")
        rtt = round((time.perf_counter() - start) * 1000, 1)
        return reply, rtt, None
    except OSError as exc:
        rtt = round((time.perf_counter() - start) * 1000, 1)
        return None, rtt, str(exc)
