/* main.js - Secure E-Commerce Network (CNIP project) */

// Mobile navigation toggle
document.addEventListener("DOMContentLoaded", function () {
  var toggle = document.getElementById("navToggle");
  var links = document.getElementById("navLinks");
  if (toggle && links) {
    toggle.addEventListener("click", function () {
      var open = links.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open);
    });
  }
});

// Network Monitoring Center — fetch demo telemetry and render charts
function initMonitoring() {
  fetch("/api/monitoring")
    .then(function (r) { return r.json(); })
    .then(function (data) {
      var c = data.cards;
      document.getElementById("c-conn").textContent = c.active_connections;
      document.getElementById("c-packets").textContent = c.packets_analyzed;
      document.getElementById("c-txn").textContent = c.encrypted_transactions;
      document.getElementById("c-resp").textContent = c.avg_response_ms + " ms";
      document.getElementById("c-status").textContent = c.network_status;

      // Lab IP cards
      var ipGrid = document.getElementById("ipGrid");
      var names = {
        client: "Client (Customer)", web: "Web Server", app: "Application Server",
        payment: "Payment Server", db: "Database Server"
      };
      Object.keys(names).forEach(function (k) {
        ipGrid.innerHTML += '<div class="ip-box"><span>' + names[k] +
          '</span><strong>' + data.lab_ips[k] + '</strong></div>';
      });

      var logs = data.logs;
      var labels = logs.map(function (l) { return l.created_at.slice(11, 19); });

      // Recent connection table (latest 12)
      var body = document.getElementById("logBody");
      body.innerHTML = "";
      logs.slice(-12).reverse().forEach(function (l) {
        body.innerHTML += "<tr><td>" + l.created_at.slice(11, 19) + "</td><td>" + l.src_ip +
          "</td><td>" + l.dst_ip + "</td><td>" + l.protocol + "</td><td>" + l.src_port +
          "</td><td>" + l.dst_port + "</td><td>" + l.packet_size + " B</td><td>" + l.seq_num +
          "</td><td>" + l.status + "</td><td>" + l.response_ms + "</td></tr>";
      });

      if (typeof Chart === "undefined") return;
      var blue = "#1e6fd9", light = "#4d94ff", dark = "#0b1f3a", warn = "#d97706", ok = "#16a34a";

      new Chart(document.getElementById("chPackets"), {
        type: "line",
        data: { labels: labels, datasets: [{ label: "Packets", data: logs.map(function (_, i) { return i + 1; }),
          borderColor: blue, backgroundColor: "rgba(30,111,217,.12)", fill: true, tension: .35, pointRadius: 0 }] },
        options: { plugins: { legend: { display: false } }, scales: { x: { ticks: { maxTicksLimit: 6 } } } }
      });

      var protos = {};
      logs.forEach(function (l) { protos[l.protocol] = (protos[l.protocol] || 0) + 1; });
      new Chart(document.getElementById("chProto"), {
        type: "doughnut",
        data: { labels: Object.keys(protos), datasets: [{ data: Object.values(protos),
          backgroundColor: [blue, light, dark, warn, ok] }] },
        options: { plugins: { legend: { position: "bottom" } } }
      });

      new Chart(document.getElementById("chResp"), {
        type: "bar",
        data: { labels: labels, datasets: [{ label: "ms", data: logs.map(function (l) { return l.response_ms; }),
          backgroundColor: "rgba(77,148,255,.75)", borderRadius: 4 }] },
        options: { plugins: { legend: { display: false } }, scales: { x: { ticks: { maxTicksLimit: 6 } } } }
      });

      new Chart(document.getElementById("chTxn"), {
        type: "line",
        data: { labels: labels, datasets: [{ label: "Bytes", data: logs.map(function (l) { return l.packet_size; }),
          borderColor: ok, backgroundColor: "rgba(22,163,74,.12)", fill: true, tension: .3, pointRadius: 0 }] },
        options: { plugins: { legend: { display: false } }, scales: { x: { ticks: { maxTicksLimit: 6 } } } }
      });
    })
    .catch(function () {
      document.getElementById("logBody").innerHTML =
        "<tr><td colspan='10'>Could not load monitoring data.</td></tr>";
    });
}
