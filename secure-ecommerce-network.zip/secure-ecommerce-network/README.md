# 🛡️ Secure E-Commerce Network using Encryption and Network Monitoring

A complete, working **CNIP academic project**: a professional e-commerce website where every
transaction is **encrypted**, transmitted over a **real TCP/IP socket**, **decrypted** by a demo
payment server, stored in **SQLite**, and observed through a **network monitoring dashboard**.

**Team:** Gouthami (E1) · Jagadeesh (J2) · Gnanaprasuna (D8)

> ⚠️ **Academic demonstration only.** No real payment gateway is connected, no real money is
> processed, and no external/unauthorised systems are scanned. Network values shown in dashboards
> are clearly labelled demo/lab data.

---

## 1. Tech Stack

| Layer      | Technology                                    |
|------------|-----------------------------------------------|
| Frontend   | HTML5, CSS3, JavaScript (responsive), Chart.js |
| Backend    | Python 3 + Flask                              |
| Database   | SQLite (`database/ecommerce.db`)              |
| Security   | Fernet (AES) encryption, PBKDF2 password hashing, Flask sessions |
| Networking | Python TCP/IP client-server sockets, IP addressing, ports |
| Analysis   | Wireshark-style packet table, authorised Nmap-style discovery (demo data) |

## 2. Requirements (Windows)

- **Python 3.10+** installed and added to PATH — https://www.python.org/downloads/
- That's it. Everything else installs with pip below.

## 3. Installation & Run

Open **Command Prompt** in the project folder and run:

```bat
pip install -r requirements.txt
python init_db.py
python app.py
```

Then open your browser at:

```
http://127.0.0.1:5000
```

> `python init_db.py` is optional — the database auto-initialises on first run —
> but running it explicitly shows the DB path and the default admin account.

### Default admin account

```
Username: admin
Password: admin123
```
Admin login page: http://127.0.0.1:5000/admin/login

## 4. TCP/IP Client-Server Demonstration (standalone)

In addition to the built-in socket demo used at checkout, two standalone scripts show the
**Client → TCP/IP → Server** exchange in a terminal:

```bat
REM Terminal 1 - start the server first
python network\server.py

REM Terminal 2 - run the client
python network\client.py
```

You will see: original message → encrypted ciphertext → connection status
(ESTABLISHED, client/server IP and ports) → server decryption → ACK response → round-trip time.
Both scripts bind to **127.0.0.1 (localhost) only** and are safe for lab use.

## 5. Project Structure

```
secure-ecommerce-network/
├── app.py                  # Flask application (all routes)
├── database.py             # SQLite schema + seed data + network log helpers
├── crypto_utils.py         # Fernet encryption/decryption helpers
├── tcp_payment_server.py   # In-app localhost TCP "payment server" (port 5050)
├── init_db.py              # DB initialiser script
├── requirements.txt
├── README.md
├── templates/              # HTML pages (Jinja2)
│   ├── base.html  index.html  login.html  register.html
│   ├── products.html  product_details.html  cart.html  checkout.html
│   ├── order_confirmation.html  my_orders.html
│   ├── monitoring.html  topology.html  packet_analysis.html
│   ├── network_discovery.html  security_center.html
│   ├── admin.html  admin_login.html  admin_product_edit.html
│   ├── about.html  404.html
├── static/
│   ├── css/style.css
│   ├── js/main.js
│   └── images/             # 12 generated product SVGs
├── network/
│   ├── client.py           # TCP client demo (encrypts + sends)
│   └── server.py           # TCP server demo (receives + decrypts)
└── database/
    ├── ecommerce.db        # created automatically
    └── demo_secret.key     # encryption key, generated on first run
```

## 6. Feature → Where to See It

| CNIP concept | Where it is demonstrated |
|---|---|
| Encryption / Decryption | Checkout → Order Confirmation page shows Original → Encrypted → Decrypted; `crypto_utils.py` |
| TCP/IP client-server | Real socket transmission on checkout (`tcp_payment_server.py`, 127.0.0.1:5050); standalone `network/client.py` + `server.py` |
| IP addressing & ports | Topology page, packet tables, terminal demo output |
| Network monitoring | `/monitoring` dashboard: stat cards + 4 charts + connection log |
| Packet analysis (Wireshark concepts) | `/packet-analysis` — demo packet table + field explanations |
| Authorised discovery (Nmap concepts) | `/network-discovery` — demo host/port/service table with ethics notice |
| Password security | PBKDF2 hashing in registration/login; hashes never displayed |
| Database | SQLite: users, products, orders, order_items, transactions, network_logs |

## 7. Test Checklist

- [ ] `python app.py` starts without errors; home page loads at http://127.0.0.1:5000
- [ ] Register a new user → validation errors show for bad input / duplicates
- [ ] Login with username *and* with email → redirects to Products
- [ ] Products: search, category filter, price sort all work; open a product detail page
- [ ] Add to cart → change quantities (+ / −) → remove item → totals update
- [ ] Checkout: form validation works (10-digit phone, 6-digit PIN)
- [ ] Confirm order → Order Confirmation shows Order ID, statuses, and the
      **Original → Encrypted → Decrypted** transaction flow with "integrity verified"
- [ ] My Orders lists the order
- [ ] Network Monitoring Center shows 5 stat cards, IP cards, 4 charts, connection log
- [ ] Topology, Packet Analysis, Network Discovery, Security Center pages load
- [ ] Admin login (admin/admin123) → view users/products/orders/transactions/logs;
      add, edit, delete a product
- [ ] Logout clears the session
- [ ] Run `network\server.py` then `network\client.py` → encrypted message round-trip shown
- [ ] Resize the browser / open on a phone → navigation collapses to a hamburger menu

## 8. Notes

- The database file and encryption key are generated automatically; delete
  `database/ecommerce.db` to reset the demo data.
- Secret key in `app.py` is a demo value — for anything beyond a classroom demo,
  load it from an environment variable.
- Chart.js is loaded from a CDN; all other assets are local. If you are fully offline,
  the monitoring charts will not render but every other feature works.
