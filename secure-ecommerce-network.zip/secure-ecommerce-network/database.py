"""
database.py - SQLite database layer for the Secure E-Commerce Network project.

Creates and initialises the database automatically. Passwords are NEVER stored
in plain text - they are hashed with Werkzeug (PBKDF2-SHA256).
"""

import os
import sqlite3
import random
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_DIR = os.path.join(BASE_DIR, "database")
DB_PATH = os.path.join(DB_DIR, "ecommerce.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    is_admin      INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    category    TEXT NOT NULL,
    price       REAL NOT NULL,
    rating      REAL NOT NULL DEFAULT 4.0,
    description TEXT NOT NULL,
    stock       INTEGER NOT NULL DEFAULT 10,
    image       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL,
    customer_name  TEXT NOT NULL,
    phone          TEXT NOT NULL,
    address        TEXT NOT NULL,
    city           TEXT NOT NULL,
    state          TEXT NOT NULL,
    pin            TEXT NOT NULL,
    payment_method TEXT NOT NULL,
    total          REAL NOT NULL,
    status         TEXT NOT NULL DEFAULT 'Confirmed',
    created_at     TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    name       TEXT NOT NULL,
    price      REAL NOT NULL,
    quantity   INTEGER NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

CREATE TABLE IF NOT EXISTS transactions (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id       INTEGER NOT NULL,
    original_data  TEXT NOT NULL,
    encrypted_data TEXT NOT NULL,
    decrypted_data TEXT NOT NULL,
    channel        TEXT NOT NULL DEFAULT 'TCP/IP localhost',
    status         TEXT NOT NULL,
    created_at     TEXT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

CREATE TABLE IF NOT EXISTS network_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    src_ip      TEXT NOT NULL,
    dst_ip      TEXT NOT NULL,
    protocol    TEXT NOT NULL,
    src_port    INTEGER NOT NULL,
    dst_port    INTEGER NOT NULL,
    packet_size INTEGER NOT NULL,
    seq_num     INTEGER NOT NULL,
    status      TEXT NOT NULL,
    response_ms REAL NOT NULL,
    created_at  TEXT NOT NULL
);
"""

# Demonstration lab topology (clearly labelled demo/local values everywhere)
LAB_IPS = {
    "client": "192.168.1.10",
    "web": "192.168.1.20",
    "app": "192.168.1.30",
    "payment": "192.168.1.40",
    "db": "192.168.1.50",
}

PRODUCTS = [
    ("Wireless Noise-Cancelling Headphones", "Electronics", 4999, 4.6,
     "Over-ear Bluetooth headphones with active noise cancellation, 40-hour battery life and fast charging.", 25, "p1.svg"),
    ("Smartphone X5 Pro (128 GB)", "Electronics", 21999, 4.4,
     "6.5-inch AMOLED display, 5G ready, 64 MP triple camera and all-day battery.", 18, "p2.svg"),
    ("Smartwatch Fit S2", "Electronics", 3499, 4.2,
     "Fitness smartwatch with heart-rate, SpO2, GPS tracking and 10-day battery.", 40, "p3.svg"),
    ("Men's Casual Cotton T-Shirt", "Fashion", 799, 4.1,
     "100% combed cotton regular-fit t-shirt, breathable and pre-shrunk fabric.", 60, "p4.svg"),
    ("Women's Floral Summer Dress", "Fashion", 1899, 4.5,
     "Lightweight knee-length floral dress, perfect for summer outings.", 30, "p5.svg"),
    ("Unisex Running Shoes", "Fashion", 2799, 4.3,
     "Breathable mesh running shoes with cushioned sole and anti-skid grip.", 35, "p6.svg"),
    ("Leather Wallet - Classic Brown", "Accessories", 999, 4.4,
     "Genuine leather bi-fold wallet with RFID-blocking card protection.", 50, "p7.svg"),
    ("Stainless Steel Water Bottle 1L", "Accessories", 649, 4.2,
     "Double-wall vacuum insulated bottle, keeps drinks cold 24h / hot 12h.", 80, "p8.svg"),
    ("Minimalist Backpack 25L", "Accessories", 1599, 4.5,
     "Water-resistant laptop backpack with USB charging port and anti-theft pocket.", 45, "p9.svg"),
    ("Ceramic Coffee Mug Set (4 pcs)", "Home", 899, 4.3,
     "Set of four 300 ml ceramic mugs, dishwasher and microwave safe.", 55, "p10.svg"),
    ("LED Desk Lamp with Dimmer", "Home", 1299, 4.4,
     "Eye-care LED desk lamp with 5 brightness levels and USB charging.", 38, "p11.svg"),
    ("Data Communications and Networking", "Books", 750, 4.7,
     "Classic textbook covering TCP/IP, routing, switching and network security fundamentals.", 22, "p12.svg"),
]


def get_db():
    """Return a SQLite connection with row access by column name."""
    os.makedirs(DB_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create tables, seed the admin account, products and demo network logs."""
    os.makedirs(DB_DIR, exist_ok=True)
    conn = get_db()
    conn.executescript(SCHEMA)

    # Seed admin (password hashed, never plain text)
    if not conn.execute("SELECT 1 FROM users WHERE username='admin'").fetchone():
        conn.execute(
            "INSERT INTO users (name, email, username, password_hash, is_admin, created_at)"
            " VALUES (?,?,?,?,1,?)",
            ("Administrator", "admin@project.local", "admin",
             generate_password_hash("admin123"), datetime.now().isoformat(timespec="seconds")),
        )

    # Seed products
    if conn.execute("SELECT COUNT(*) c FROM products").fetchone()["c"] == 0:
        conn.executemany(
            "INSERT INTO products (name, category, price, rating, description, stock, image)"
            " VALUES (?,?,?,?,?,?,?)",
            PRODUCTS,
        )

    # Seed demonstration network logs (clearly labelled demo/lab data)
    if conn.execute("SELECT COUNT(*) c FROM network_logs").fetchone()["c"] == 0:
        seed_demo_logs(conn)

    conn.commit()
    conn.close()


def seed_demo_logs(conn, count=60):
    """Insert simulated packet log rows for the monitoring dashboard demo."""
    hosts = [("web", 80, "HTTP"), ("web", 443, "HTTPS"),
             ("app", 5000, "TCP"), ("payment", 5050, "TCP"), ("db", 5432, "TCP")]
    now = datetime.now()
    rows = []
    seq = 1000
    for i in range(count):
        host, dport, proto = random.choice(hosts)
        t = (now - timedelta(minutes=(count - i) * 5)).isoformat(timespec="seconds")
        size = random.choice([64, 128, 256, 512, 1024, 1460])
        resp = round(random.uniform(2, 95), 1)
        seq += random.randint(1, size)
        rows.append((LAB_IPS["client"], LAB_IPS[host], proto,
                     random.randint(49152, 65535), dport, size, seq,
                     "ESTABLISHED" if random.random() > 0.08 else "CLOSED",
                     resp, t))
    conn.executemany(
        "INSERT INTO network_logs (src_ip, dst_ip, protocol, src_port, dst_port,"
        " packet_size, seq_num, status, response_ms, created_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?)", rows)


def log_network_event(conn, dst_key, dst_port, protocol, size, response_ms,
                      status="ESTABLISHED", src_ip=None):
    """Record one network event (used when a real demo transaction happens)."""
    conn.execute(
        "INSERT INTO network_logs (src_ip, dst_ip, protocol, src_port, dst_port,"
        " packet_size, seq_num, status, response_ms, created_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?)",
        (src_ip or LAB_IPS["client"], LAB_IPS.get(dst_key, "192.168.1.30"),
         protocol, random.randint(49152, 65535), dst_port, size,
         random.randint(1000, 999999), status, response_ms,
         datetime.now().isoformat(timespec="seconds")))


if __name__ == "__main__":
    init_db()
    print(f"Database initialised at {DB_PATH}")
