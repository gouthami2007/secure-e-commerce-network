"""init_db.py - Initialise the SQLite database (tables + demo seed data)."""

from database import init_db, DB_PATH

if __name__ == "__main__":
    init_db()
    print("Database ready:", DB_PATH)
    print("Default admin account -> username: admin  password: admin123")
