"""
network/client.py - Standalone TCP/IP client demonstration.

Builds a demo transaction message, encrypts it with the project demo key,
sends it over a real TCP socket to network/server.py, and prints the full
Client -> TCP/IP -> Server exchange (IP, port, message, status, response).

Run after the server:  python network/client.py
"""

import socket
import sys
import os
import time
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from crypto_utils import encrypt_text  # noqa: E402

HOST = "127.0.0.1"   # server IP (localhost - safe lab demo)
PORT = 5051          # server port


def main():
    print("=" * 60)
    print(" CNIP DEMO - TCP/IP CLIENT (localhost only)")
    print("=" * 60)

    message = (f"TXN-DEMO|order_id=1001|amount=4999.00|method=UPI-DEMO|"
               f"time={datetime.now().isoformat(timespec='seconds')}")
    print(f"[ORIGINAL ] {message}")

    encrypted = encrypt_text(message)
    print(f"[ENCRYPTED] {encrypted[:80]}{'...' if len(encrypted) > 80 else ''}")
    print(f"[CONNECT  ] {HOST}:{PORT} ...")

    start = time.perf_counter()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((HOST, PORT))
            local_ip, local_port = s.getsockname()
            print(f"[STATUS   ] ESTABLISHED  client {local_ip}:{local_port}"
                  f" -> server {HOST}:{PORT}  protocol TCP")
            s.sendall(encrypted.encode("ascii"))
            print(f"[SENT     ] {len(encrypted)} bytes of ciphertext")
            reply = s.recv(8192).decode("utf-8", errors="replace")
        rtt = round((time.perf_counter() - start) * 1000, 1)
        print(f"[RESPONSE ] {reply}")
        print(f"[RTT      ] {rtt} ms")
        print("\nDemo complete: Client -> Encryption -> TCP/IP -> Server -> Decryption -> ACK")
    except OSError as exc:
        print(f"[ERROR] Could not reach server at {HOST}:{PORT} -> {exc}")
        print("Start the server first:  python network/server.py")


if __name__ == "__main__":
    main()
