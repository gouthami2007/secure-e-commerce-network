"""
network/server.py - Standalone TCP/IP server demonstration.

Listens on 127.0.0.1:5051 (localhost only - safe for lab use).
Receives a (possibly encrypted) message from network/client.py, decrypts it
with the project demo key, prints the details, and sends back an ACK.

Run first:  python network/server.py
Then:       python network/client.py
"""

import socket
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from crypto_utils import decrypt_text  # noqa: E402

HOST = "127.0.0.1"
PORT = 5051


def main():
    print("=" * 60)
    print(" CNIP DEMO - TCP/IP SERVER (localhost only)")
    print("=" * 60)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((HOST, PORT))
        srv.listen(5)
        print(f"[LISTENING] Server IP: {HOST}  Port: {PORT}")
        print("Waiting for client connections... (Ctrl+C to stop)\n")
        while True:
            conn, addr = srv.accept()
            with conn:
                print(f"[CONNECTED] Client {addr[0]}:{addr[1]} - status: ESTABLISHED")
                data = conn.recv(8192)
                if not data:
                    continue
                token = data.decode("ascii", errors="replace").strip()
                print(f"[RECEIVED] Encrypted message ({len(token)} bytes):")
                print(f"           {token[:80]}{'...' if len(token) > 80 else ''}")
                try:
                    plain = decrypt_text(token)
                    print(f"[DECRYPTED] {plain}")
                    reply = f"ACK|Message decrypted and processed by server {HOST}:{PORT}"
                except Exception:
                    reply = "NACK|Could not decrypt message"
                    print("[ERROR] Decryption failed - invalid key or corrupted data")
                conn.sendall(reply.encode("utf-8"))
                print(f"[RESPONSE] {reply}\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nServer stopped.")
