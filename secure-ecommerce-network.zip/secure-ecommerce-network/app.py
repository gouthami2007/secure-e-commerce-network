"""
app.py - Secure E-Commerce Network using Encryption and Network Monitoring
CNIP academic project - Flask application entry point.

Team: Gouthami (E1) | Jagadeesh (J2) | Gnanaprasuna (D8)

Run:
    pip install -r requirements.txt
    python init_db.py        (optional - the DB auto-initialises on first run)
    python app.py
Then open http://127.0.0.1:5000
"""

import functools
import json
import re
from datetime import datetime

from flask import (Flask, render_template, request, redirect, url_for,
                   session, flash, jsonify, abort)
from werkzeug.security import generate_password_hash, check_password_hash

from database import get_db, init_db, LAB_IPS, log_network_event
from crypto_utils import encrypt_text, decrypt_text
import tcp_payment_server

app = Flask(__name__)
app.secret_key = "cnip-demo-secret-key-change-me"  # demo only

init_db()
tcp_payment_server.start_payment_server(decrypt_text)

CATEGORIES = ["Electronics", "Fashion", "Accessories", "Home", "Books"]
PAYMENT_METHODS = ["Demo UPI", "Demo Card", "Cash on Delivery"]


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    conn.close()
    return row


@app.context_processor
def inject_globals():
    cart = session.get("cart", {})
    return {
        "user": current_user(),
        "cart_count": sum(cart.values()),
        "categories": CATEGORIES,
        "lab_ips": LAB_IPS,
        "year": datetime.now().year,
    }


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user or not user["is_admin"]:
            flash("Admin access required.", "danger")
            return redirect(url_for("admin_login"))
        return view(*args, **kwargs)
    return wrapped


def get_cart_items(conn):
    cart = session.get("cart", {})
    items, subtotal = [], 0.0
    for pid, qty in cart.items():
        p = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        if p:
            qty = min(qty, p["stock"]) if p["stock"] > 0 else 0
            line = round(p["price"] * qty, 2)
            subtotal += line
            items.append({"product": p, "qty": qty, "line_total": line})
    return items, round(subtotal, 2)


# --------------------------------------------------------------------------- #
# Public pages
# --------------------------------------------------------------------------- #

@app.route("/")
def index():
    conn = get_db()
    featured = conn.execute(
        "SELECT * FROM products ORDER BY rating DESC LIMIT 4").fetchall()
    stats = {
        "transactions": conn.execute("SELECT COUNT(*) c FROM transactions").fetchone()["c"],
        "packets": conn.execute("SELECT COUNT(*) c FROM network_logs").fetchone()["c"],
        "orders": conn.execute("SELECT COUNT(*) c FROM orders").fetchone()["c"],
    }
    conn.close()
    return render_template("index.html", featured=featured, stats=stats)


@app.route("/about")
def about():
    return render_template("about.html")


# --------------------------------------------------------------------------- #
# Authentication
# --------------------------------------------------------------------------- #

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")

        errors = []
        if len(name) < 2:
            errors.append("Please enter your full name.")
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
            errors.append("Please enter a valid email address.")
        if not re.match(r"^[a-z0-9_]{3,20}$", username):
            errors.append("Username must be 3-20 chars (letters, digits, underscore).")
        if len(password) < 6:
            errors.append("Password must be at least 6 characters.")
        if password != confirm:
            errors.append("Passwords do not match.")

        conn = get_db()
        if not errors:
            if conn.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
                errors.append("That username is already taken.")
            if conn.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone():
                errors.append("That email is already registered.")
        if errors:
            conn.close()
            for e in errors:
                flash(e, "danger")
            return render_template("register.html", form=request.form), 400

        conn.execute(
            "INSERT INTO users (name, email, username, password_hash, created_at)"
            " VALUES (?,?,?,?,?)",
            (name, email, username, generate_password_hash(password),
             datetime.now().isoformat(timespec="seconds")))
        conn.commit()
        conn.close()
        flash("Registration successful! Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html", form={})


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        ident = request.form.get("identifier", "").strip().lower()
        password = request.form.get("password", "")
        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE username=? OR email=?", (ident, ident)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Welcome back, {user['name']}!", "success")
            return redirect(request.args.get("next") or url_for("products"))
        flash("Invalid username/email or password.", "danger")
        return render_template("login.html"), 401
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out securely.", "info")
    return redirect(url_for("index"))


# --------------------------------------------------------------------------- #
# Products & cart
# --------------------------------------------------------------------------- #

@app.route("/products")
def products():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "")
    sort = request.args.get("sort", "")

    sql, params = "SELECT * FROM products WHERE 1=1", []
    if q:
        sql += " AND (name LIKE ? OR description LIKE ?)"
        params += [f"%{q}%", f"%{q}%"]
    if category in CATEGORIES:
        sql += " AND category=?"
        params.append(category)
    if sort == "price_asc":
        sql += " ORDER BY price ASC"
    elif sort == "price_desc":
        sql += " ORDER BY price DESC"
    elif sort == "rating":
        sql += " ORDER BY rating DESC"
    else:
        sql += " ORDER BY id"

    conn = get_db()
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return render_template("products.html", products=rows, q=q,
                           category=category, sort=sort)


@app.route("/product/<int:pid>")
def product_details(pid):
    conn = get_db()
    p = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    related = conn.execute(
        "SELECT * FROM products WHERE category=? AND id!=? LIMIT 4",
        (p["category"], pid)).fetchall() if p else []
    conn.close()
    if not p:
        abort(404)
    return render_template("product_details.html", p=p, related=related)


@app.route("/cart")
def cart():
    conn = get_db()
    items, subtotal = get_cart_items(conn)
    conn.close()
    shipping = 0.0 if subtotal == 0 or subtotal >= 999 else 49.0
    return render_template("cart.html", items=items, subtotal=subtotal,
                           shipping=shipping, total=round(subtotal + shipping, 2))


@app.route("/cart/add/<int:pid>", methods=["POST"])
def cart_add(pid):
    conn = get_db()
    p = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    conn.close()
    if not p:
        abort(404)
    qty = max(1, int(request.form.get("qty", 1)))
    cart = session.get("cart", {})
    cart[str(pid)] = min(cart.get(str(pid), 0) + qty, p["stock"])
    session["cart"] = cart
    flash(f"Added '{p['name']}' to your cart.", "success")
    return redirect(request.form.get("next") or url_for("products"))


@app.route("/cart/update/<int:pid>", methods=["POST"])
def cart_update(pid):
    action = request.form.get("action", "")
    cart = session.get("cart", {})
    key = str(pid)
    if key in cart:
        if action == "inc":
            cart[key] += 1
        elif action == "dec":
            cart[key] -= 1
        if cart[key] <= 0 or action == "remove":
            cart.pop(key)
    session["cart"] = cart
    return redirect(url_for("cart"))


# --------------------------------------------------------------------------- #
# Checkout + secure transaction demo
# --------------------------------------------------------------------------- #

@app.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    conn = get_db()
    items, subtotal = get_cart_items(conn)
    if not items:
        conn.close()
        flash("Your cart is empty.", "warning")
        return redirect(url_for("products"))
    shipping = 0.0 if subtotal >= 999 else 49.0
    total = round(subtotal + shipping, 2)

    if request.method == "POST":
        f = request.form
        required = ["customer_name", "phone", "address", "city", "state", "pin"]
        if any(not f.get(k, "").strip() for k in required):
            conn.close()
            flash("Please fill in all delivery fields.", "danger")
            return render_template("checkout.html", items=items, subtotal=subtotal,
                                   shipping=shipping, total=total,
                                   methods=PAYMENT_METHODS, form=f), 400
        if not re.match(r"^\d{10}$", f.get("phone", "").strip()):
            conn.close()
            flash("Phone number must be 10 digits.", "danger")
            return render_template("checkout.html", items=items, subtotal=subtotal,
                                   shipping=shipping, total=total,
                                   methods=PAYMENT_METHODS, form=f), 400
        payment = f.get("payment_method", "Cash on Delivery")
        if payment not in PAYMENT_METHODS:
            payment = "Cash on Delivery"

        user = current_user()
        cur = conn.execute(
            "INSERT INTO orders (user_id, customer_name, phone, address, city, state,"
            " pin, payment_method, total, status, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (user["id"], f["customer_name"].strip(), f["phone"].strip(),
             f["address"].strip(), f["city"].strip(), f["state"].strip(),
             f["pin"].strip(), payment, total, "Confirmed",
             datetime.now().isoformat(timespec="seconds")))
        order_id = cur.lastrowid
        for it in items:
            conn.execute(
                "INSERT INTO order_items (order_id, product_id, name, price, quantity)"
                " VALUES (?,?,?,?,?)",
                (order_id, it["product"]["id"], it["product"]["name"],
                 it["product"]["price"], it["qty"]))
            new_stock = max(0, it["product"]["stock"] - it["qty"])
            conn.execute("UPDATE products SET stock=? WHERE id=?",
                         (new_stock, it["product"]["id"]))

        # ---- SECURE TRANSACTION DEMO -------------------------------------
        # 1) Build the original transaction payload
        payload = json.dumps({
            "order_id": order_id,
            "customer": f["customer_name"].strip(),
            "amount": total,
            "payment_method": payment,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "note": "ACADEMIC DEMO - no real payment data",
        })
        # 2) Encrypt it (Fernet AES)
        encrypted = encrypt_text(payload)
        # 3) Transmit over a real localhost TCP/IP socket to the payment server
        reply, rtt, err = tcp_payment_server.transmit_encrypted(encrypted)
        # 4) Server decrypts; we verify the round-trip locally
        channel = "TCP/IP 127.0.0.1:5050"
        if err or not reply or not reply.startswith("ACK|DECRYPTED|"):
            decrypted = decrypt_text(encrypted)   # local fallback decryption
            status = "Encrypted & Verified (local fallback)"
            channel = "Local crypto verification (socket unavailable)"
        else:
            decrypted = reply.split("|", 2)[2]
            status = "Encrypted and Successfully Transmitted"
        ok = decrypted == payload
        if not ok:
            status = "Integrity check failed"

        conn.execute(
            "INSERT INTO transactions (order_id, original_data, encrypted_data,"
            " decrypted_data, channel, status, created_at) VALUES (?,?,?,?,?,?,?)",
            (order_id, payload, encrypted, decrypted, channel, status,
             datetime.now().isoformat(timespec="seconds")))
        log_network_event(conn, "payment", 5050, "TCP", len(encrypted), rtt,
                          "ESTABLISHED" if not err else "LOCAL",
                          src_ip=request.remote_addr or "127.0.0.1")
        conn.commit()
        conn.close()

        session["cart"] = {}
        return redirect(url_for("order_confirmation", order_id=order_id))

    conn.close()
    return render_template("checkout.html", items=items, subtotal=subtotal,
                           shipping=shipping, total=total,
                           methods=PAYMENT_METHODS, form={})


@app.route("/order/<int:order_id>")
@login_required
def order_confirmation(order_id):
    conn = get_db()
    order = conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order or (order["user_id"] != session["user_id"] and not current_user()["is_admin"]):
        conn.close()
        abort(404)
    items = conn.execute("SELECT * FROM order_items WHERE order_id=?", (order_id,)).fetchall()
    txn = conn.execute(
        "SELECT * FROM transactions WHERE order_id=? ORDER BY id DESC LIMIT 1",
        (order_id,)).fetchone()
    conn.close()
    return render_template("order_confirmation.html", order=order, items=items, txn=txn)


@app.route("/my-orders")
@login_required
def my_orders():
    conn = get_db()
    orders = conn.execute(
        "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC",
        (session["user_id"],)).fetchall()
    item_map = {}
    for o in orders:
        item_map[o["id"]] = conn.execute(
            "SELECT * FROM order_items WHERE order_id=?", (o["id"],)).fetchall()
    conn.close()
    return render_template("my_orders.html", orders=orders, item_map=item_map)


# --------------------------------------------------------------------------- #
# Network monitoring / analysis pages
# --------------------------------------------------------------------------- #

@app.route("/monitoring")
def monitoring():
    return render_template("monitoring.html")


@app.route("/api/monitoring")
def api_monitoring():
    conn = get_db()
    logs = conn.execute(
        "SELECT * FROM network_logs ORDER BY id DESC LIMIT 200").fetchall()
    conn.close()
    rows = [dict(r) for r in logs][::-1]  # chronological
    cards = {
        "active_connections": sum(1 for r in rows if r["status"] == "ESTABLISHED"),
        "packets_analyzed": len(rows),
        "encrypted_transactions": get_db().execute(
            "SELECT COUNT(*) c FROM transactions").fetchone()["c"],
        "avg_response_ms": round(sum(r["response_ms"] for r in rows) / max(1, len(rows)), 1),
        "network_status": "Healthy",
    }
    return jsonify({"cards": cards, "logs": rows, "lab_ips": LAB_IPS,
                    "demo": True})


@app.route("/topology")
def topology():
    return render_template("topology.html")


@app.route("/packet-analysis")
def packet_analysis():
    conn = get_db()
    packets = conn.execute(
        "SELECT * FROM network_logs ORDER BY id DESC LIMIT 15").fetchall()
    conn.close()
    return render_template("packet_analysis.html", packets=packets)


@app.route("/network-discovery")
def network_discovery():
    # Demonstration/local lab data only - NOT a live scan of any system.
    hosts = [
        {"host": "192.168.1.20 (web-server)", "status": "up", "port": 80,
         "service": "HTTP", "protocol": "TCP"},
        {"host": "192.168.1.20 (web-server)", "status": "up", "port": 443,
         "service": "HTTPS", "protocol": "TCP"},
        {"host": "192.168.1.30 (app-server)", "status": "up", "port": 5000,
         "service": "Flask Application Server", "protocol": "TCP"},
        {"host": "192.168.1.40 (payment-server)", "status": "up", "port": 5050,
         "service": "Demo Payment TCP Service", "protocol": "TCP"},
        {"host": "192.168.1.50 (db-server)", "status": "up", "port": 5432,
         "service": "Database Server (SQLite file in this demo)", "protocol": "TCP"},
        {"host": "127.0.0.1 (localhost)", "status": "up", "port": 22,
         "service": "SSH (filtered in lab)", "protocol": "TCP"},
    ]
    return render_template("network_discovery.html", hosts=hosts)


@app.route("/security-center")
def security_center():
    conn = get_db()
    txn_count = conn.execute("SELECT COUNT(*) c FROM transactions").fetchone()["c"]
    user_count = conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
    log_count = conn.execute("SELECT COUNT(*) c FROM network_logs").fetchone()["c"]
    conn.close()
    return render_template("security_center.html", txn_count=txn_count,
                           user_count=user_count, log_count=log_count)


# --------------------------------------------------------------------------- #
# Admin
# --------------------------------------------------------------------------- #

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        ident = request.form.get("identifier", "").strip().lower()
        password = request.form.get("password", "")
        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE (username=? OR email=?) AND is_admin=1",
            (ident, ident)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash("Admin login successful.", "success")
            return redirect(url_for("admin_dashboard"))
        flash("Invalid admin credentials.", "danger")
        return render_template("admin_login.html"), 401
    return render_template("admin_login.html")


@app.route("/admin")
@admin_required
def admin_dashboard():
    conn = get_db()
    data = {
        "users": conn.execute("SELECT * FROM users ORDER BY id").fetchall(),
        "products": conn.execute("SELECT * FROM products ORDER BY id").fetchall(),
        "orders": conn.execute("SELECT * FROM orders ORDER BY id DESC").fetchall(),
        "transactions": conn.execute(
            "SELECT * FROM transactions ORDER BY id DESC LIMIT 20").fetchall(),
        "logs": conn.execute(
            "SELECT * FROM network_logs ORDER BY id DESC LIMIT 20").fetchall(),
        "counts": {
            "users": conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"],
            "products": conn.execute("SELECT COUNT(*) c FROM products").fetchone()["c"],
            "orders": conn.execute("SELECT COUNT(*) c FROM orders").fetchone()["c"],
            "transactions": conn.execute("SELECT COUNT(*) c FROM transactions").fetchone()["c"],
        },
    }
    conn.close()
    return render_template("admin.html", **data)


@app.route("/admin/product/add", methods=["POST"])
@admin_required
def admin_product_add():
    f = request.form
    conn = get_db()
    conn.execute(
        "INSERT INTO products (name, category, price, rating, description, stock, image)"
        " VALUES (?,?,?,?,?,?,?)",
        (f["name"].strip(), f["category"], float(f["price"]),
         float(f.get("rating", 4.0)), f["description"].strip(),
         int(f["stock"]), f.get("image", "p1.svg")))
    conn.commit()
    conn.close()
    flash("Product added.", "success")
    return redirect(url_for("admin_dashboard", _anchor="products"))


@app.route("/admin/product/edit/<int:pid>", methods=["GET", "POST"])
@admin_required
def admin_product_edit(pid):
    conn = get_db()
    if request.method == "POST":
        f = request.form
        conn.execute(
            "UPDATE products SET name=?, category=?, price=?, rating=?,"
            " description=?, stock=? WHERE id=?",
            (f["name"].strip(), f["category"], float(f["price"]),
             float(f.get("rating", 4.0)), f["description"].strip(),
             int(f["stock"]), pid))
        conn.commit()
        conn.close()
        flash("Product updated.", "success")
        return redirect(url_for("admin_dashboard", _anchor="products"))
    p = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    conn.close()
    if not p:
        abort(404)
    return render_template("admin_product_edit.html", p=p)


@app.route("/admin/product/delete/<int:pid>", methods=["POST"])
@admin_required
def admin_product_delete(pid):
    conn = get_db()
    conn.execute("DELETE FROM products WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    flash("Product deleted.", "info")
    return redirect(url_for("admin_dashboard", _anchor="products"))


@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
